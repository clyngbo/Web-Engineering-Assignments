<?php

session_start();
foreach (glob("model/*.php") as $filename)
{
    include_once $filename;
}
foreach (glob("controller/*.php") as $filename)
{
    include_once $filename;
}
include_once 'menu.php';
include_once 'footer.php';

function getCSS()
{
    echo '<link rel="stylesheet" href="css.css">';
    echo '<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Raleway" />';

}

function getJS()
{
    echo '<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>';

    echo '<script type="text/javascript" src="js.js"></script>';
}
?>