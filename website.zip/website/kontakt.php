<?php
include 'init.php';
$succes = "";
$error = "";
if(isset($_POST['send_mail']))
{
    $navn = $_POST['name'];
    $email = $_POST['email'];
    $emne = $_POST['subject'];
    $besked = $_POST['message'];
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $to = "jeniith@jeniithphotography.dk";
    if($navn == "" | $email == "" | $besked == "" | $emne == "")
    {
        $error = "Du har ikke udfyldt alle felter. Beskeden kan ikke sendes, medmindre alle felter er udfyldte.";
    }
    else
    {
        if(mail($to, $emne, "Besked fra: $email <br>" . $besked, $headers))
        {
            $succes = "Beskeden er blevet sendt og du vil få svar hurtigst muligt.";
        }
    }
}
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="description" content="Kontakt mig via kontaktformen og for at høre mere om mine gode priser!">
        <?php
        getCSS();
        ?>
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <title>Jeniith Photography | Kontakt</title>
    </head>
    <body>
        <?php
        getMenu();
        
        
        
        ?>
        
        <form action="kontakt.php" method="post" class="contact-form">
        <div id="reviews-outer-div">
        
        <table id="impressum">
            <tr>
                <td><img src="https://static.wixstatic.com/media/0b9c93_0c572549f8694720a85f7825cf4bfe2c~mv2_d_2048_1365_s_2.jpg/v1/fill/w_498,h_356,al_c,q_80,usm_0.66_1.00_0.01/0b9c93_0c572549f8694720a85f7825cf4bfe2c~mv2_d_2048_1365_s_2.jpg" alt="Jeniith Jeyanthisivam"></td>
                <td><div id="header">Kontakt</div>Jeg har fotograferet i over 4 år, og har haft det som en seriøs fritidsinteresse. Jeg er nu ved at udvide min portfolio, da jeg gerne vil gå fra en fritidsinteresse til en hobbyvirksomhed. Jeg tilbyder fotografering efter princippet “Name your price”, hvilket vil sige, at du som kunde kommer med den pris, du vil betale for en fotografering. Inden for 24 timer vil jeg acceptere, komme med et alternativt tilbud der vil matche dine forventning, eller afvise tilbudet. Kontakt mig for yderligere informationer.</td>
            </tr>
        </table>
            <p id="warning"><?php
            echo $error;
        
            
            ?></p>
            <p id="succes"><?php echo $succes; ?> </p>
        <table id="contact-table">
            <tr>
                <td><input type="text" name="name" class="contact-input" placeholder="Navn"></td>
                <td><input type="text" name="email" class="contact-input" placeholder="Email"></td>
            </tr>
            <tr>
                <td colspan="2"><input type="text" name="subject" class="contact-input" placeholder="Emne"></td>
                
            </tr>
            <tr>
                <td colspan="2"><textarea placeholder="Besked" name="message" class="contact-textarea"></textarea></td>
                
            </tr>
            <tr>
                <td colspan="2"><input id="send-btn" type="submit" value="Send besked" name="send_mail" /> <input id="btn" type="reset" value="Ryd alle felter" name="reset" /></td>
            </tr>
       
        </table>
        
        </div>
        </form>
        
        
            
        <?php
        
        
        getFooter();
        ?>
        <script src="js.js"></script>
    </body>
</html>
