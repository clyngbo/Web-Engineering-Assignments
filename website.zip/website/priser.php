<?php
include 'init.php';
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="description" content="Kom og se de billige priser for fotosessioner!">
        <?php
        getCSS();
        ?>
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <title>Jeniith Photography | Priser</title>
    </head>
    <body>
        <?php
        getMenu();
        
        
        
        ?>
        <div id="reviews-outer-div">
        <div id="header">Priser</div>
        <table id="prices-table">
            <tr>
                <th>Ydelse</th>
                <th>Pris inkl. moms</th>
            </tr>
            <tr>
                <td>Fotosession ½ time</td>
                <td>500 kr</td>
            </tr>
            <tr>
                <td>Fotosession 1 time</td>
                <td>900 kr</td>
            </tr>
            <tr>
                <td>Pasfoto 9 stk.</td>
                <td>300 kr</td>
            </tr>
        </table>
        </div>
        
        
            
        <?php
        
        
        getFooter();
        ?>
        <script src="js.js"></script>
    </body>
</html>
