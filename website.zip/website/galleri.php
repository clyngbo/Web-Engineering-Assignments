<?php
include 'init.php';



?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="description" content="Kom og se de spændende billeder i mit portfolie!">
        <?php
        getCSS();
        getJS();
        ?>
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

        <title>Jeniith Photography | Galleri</title>
    </head>
    <body>
        <?php
        getMenu();
        ?>
        
        <div id="gallery-folders">    
            <div id="header"><?php 
        
        if(isset($_GET['galleri'])){
        echo basename($_GET['galleri']); }
        else{
            echo "Galleri";
        }?></div>
        <?php
        $dir = "images/portfolio";
        if(isset($_GET['galleri']))
        {
            $dir = $_GET['galleri'];
        }
//        $scanned_dir = array_diff(scandir($dir, SCANDIR_SORT_ASCENDING), array('.', '..'));
        foreach(glob($dir."/*", GLOB_ONLYDIR) as $d)
        {
            
            ?>
            <a href="galleri.php?galleri=<?php echo $d; ?>"><div id="folder">
                <img id="thumbnail" src="<?php echo $d . "/thumbnail.jpeg" ?>" alt="thumbnail">
                <div id="caption"><?php echo basename($d); ?></div>
                </div></a>
                <?php
            
        }
        ?>
            <section
      data-featherlight-gallery
      data-featherlight-filter="a"
    >
            <div id="gallery-div"><ul id="gallery"><?php
        foreach(glob($dir."/*.{jpg,JPG,jpeg,JPEG,png,PNG}", GLOB_BRACE) as $image)
        {
            if(basename($image) != "thumbnail.jpeg")
            {
                ?><li>
                    <a class="gallery" href="<?php echo $image; ?>"><img id="image" src="<?php echo $image; ?>" alt="Portfolie billede"></a></li>
                    <?php
            }
        }

        ?></ul></div></section>
        </div>    
            <?php
     
        getFooter();
        ?>
        <script src="js.js"></script>

        <script type="text/javascript">
        
        </script>
    </body>
</html>
