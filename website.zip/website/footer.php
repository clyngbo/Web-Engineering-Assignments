<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function getFooter()
{
    ?>
<footer>
<table id="footer-table">
    <tr>
        <td>
            <a href="mailto:jeniith@jeniithphotography.dk">Skriv en mail til mig.</a>
        </td>
        <td>
            Mobil: 42 72 72 09
        </td>
    </tr>
</table>    
<div id="socialmedia-div">
<ul id="socialmedia">
    <li><a href="https://www.facebook.com/pg/JeniithPhotography/about/?ref=page_internal"><img id="socialmediaImage" src="images/facebook.png" alt="Facebook"></a></li>
    <li><a href="https://www.instagram.com/jeniithphotography/"><img id="socialmediaImage" src="images/instagram.png" alt="Instagram"></a></li>
    
</ul></div></footer>
    <?php
}

?>