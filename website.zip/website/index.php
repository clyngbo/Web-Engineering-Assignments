<?php
include 'init.php';
$frontpage_ctr = new Frontpage_ctr();
$reviews = $frontpage_ctr->getAllReviews();
$frontpageText = $frontpage_ctr->getFrontpageText();
$frontpageGallery = $frontpage_ctr->getFrontpageGallery();
?>
<!DOCTYPE html>


<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="description" content="Fotograf i Aalborg. Jeg tager imod alle slags fotograf opgaver. Kontakt mig for at høre mere.">
        <?php
        getCSS();
        ?>
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="jquery.carouFredSel-6.0.4-packed.js" type="text/javascript"></script>
		<script type="text/javascript">
			$(function() {
				$('#carousel').carouFredSel({
					width: '100%',
					items: {
						visible: 3,
						start: -1
					},
					scroll: {
						items: 1,
						duration: 2000,
						timeoutDuration: 4000
					},
					prev: '#prev',
					next: '#next',
					pagination: {
						container: '#pager',
						deviation: 1
					}
				});
			});
		</script>
		<style type="text/css">
			
			
			
		</style>
        <title>Jeniith Photography</title>
    </head>
    <body>
        <?php
        
        getMenu();
        ?>
        <div id="wrapper">
			<div id="carousel">
                            <?php
                            foreach($frontpageGallery as $image)
                            {
                                echo '<img src="'.$image->image.'" alt="slideshow" width="990" height="450"/>';
                            }
                            ?>
				
			</div>
			<a href="#" id="prev" title="Forrige"> </a>
			<a href="#" id="next" title="Næste"> </a>
			<div id="pager"></div>
		</div>
        <?php
        
        if(strlen($frontpageText->frontpageText)>0)
        {
            ?>
        <div id="reviews-outer-div">
        <div id="header">Besked fra Jeniith Photography:</div>
        <div id="frontpageText"><?php echo $frontpageText->frontpageText; ?></div>    
        </div>
            <?php
        }
        ?>
        
        <div id="reviews-outer-div">
            <div id="header">
                Anbefalinger
            </div>    
            <div id="reviews">
                <?php
                if($reviews[0] != NULL)
                {
                    foreach($reviews as $review)
                    {
                        ?>
                <div id="review">
                   
                        <div id="review-text"> <img id="review-image" src="<?php echo $review->image; ?>" alt="Anbefaling af <?php echo $review->name; ?>"> <?php echo $review->review;?></div>
                        <div id="review-name"><?php echo $review->name; ?></div>
                        <div id="review-location"><?php echo $review->location; ?></div>
                </div>
                        <?php
                    }
                }
                else{
                    echo 'Der er ingen anbefalinger.';
                }
                ?>
            </div>
        </div>
        
        <script src="js.js">
        
           
        </script>
        <?php
        getFooter();
        ?>
    </body>
</html>
