<?php
include_once 'Control_init.php';
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Gallery_ctr
{
    private $conn;
    public function __construct() {
        $this->conn = new DBConnection();
    }
    
    public function getGallery($categoryID)
    {
        $sql = "SELECT * FROM Gallery WHERE categoryID = $categoryID;";
        $result = $this->conn->query($sql);
        $gals = new ArrayObject();
        while ($row = $result->fetch_assoc()) {
            $gal = new Gallery_model();
            $gal->caption = $row['caption'];
            $gal->categoryID = $row['categoryID'];
            $gal->galleryID = $row['galleryID'];
            $gal->imagePath = $row['imagePath'];
            $gals->append($gal);
        }
        return $gals;
    }
    
    public function createGallery(Gallery_model $gallery)
    {
        $sql = "INSERT INTO Gallery(caption, imagePath, categoryID) VALUES ('$gallery->caption','$gallery->imagePath','$gallery->categoryID');";
        return $this->conn->statement($sql);
    }
    
    public function updateGallery(Gallery_model $gallery)
    {
        $sql = "UPDATE Gallery SET caption = '$gallery->caption', imagePath = '$gallery->imagePath', categoryID = '$gallery->categoryID' WHERE galleryID = $gallery->galleryID;";
        return $this->conn->statement($sql);
    }
    
    public function deleteGallery($categoryID)
    {
        $sql = "DELETE FROM Gallery WHERE categoryID = $categoryID";
        return $this->conn->statement($sql);
    }
}

?>