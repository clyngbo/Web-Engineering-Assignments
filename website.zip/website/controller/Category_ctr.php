<?php
include_once 'Control_init.php';
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Category_ctr
{
    private $conn;
    public function __construct() {
        $this->conn = new DBConnection();
    }
    
    public function getCategory($superCategory = NULL)
    {
        $sql = "SELECT * FROM Category WHERE superCategory = '$superCategory';";
        $result = $this->conn->query($sql);
        $cats = new ArrayObject();
        while($row = $result->fetch_assoc()){
            $cat = new Category_model();
            $cat->categoryID = $row['categoryID'];
            $cat->categoryName = $row['categoryName'];
            $cat->hasGallery = $row['hasGallery'];
            $cat->image = $row['image'];
            $cat->superCategory = $row['superCategory'];
            $cat->isRoot = $row['isRoot'];
            $cats->append($cat);
        }
        return $cats;
    }
    
    public function getCategoryByID($catID)
    {
        $sql = "SELECT * FROM Category WHERE categoryID = $catID";
        $cat = new Category_model();
        $result = $this->conn->query($sql);
        while($row = $result->fetch_assoc()){
            $cat->categoryID = $row['categoryID'];
            $cat->categoryName = $row['categoryName'];
            $cat->hasGallery = $row['hasGallery'];
            $cat->image = $row['image'];
            $cat->isRoot = $row['isRoot'];
            $cat->superCategory = $row['superCategory'];
        }
        return $cat;
    }
    
    public function getRootCat()
    {
        $sql = "SELECT * FROM Category WHERE isRoot = 1";
        $cat = new Category_model();
        $result = $this->conn->query($sql);
        while($row = $result->fetch_assoc()){
            $cat->categoryID = $row['categoryID'];
            $cat->categoryName = $row['categoryName'];
            $cat->hasGallery = $row['hasGallery'];
            $cat->image = $row['image'];
            $cat->isRoot = $row['isRoot'];
            $cat->superCategory = $row['superCategory'];
        }
        return $cat;
    }

    public function createCategory(Category_model $category)
    {
        $sql = "INSERT INTO Category(image, hasGallery, categoryName, superCategory, isRoot) VALUES('$category->image','$category->hasGallery','$category->categoryName','$category->superCategory', '$category->isRoot');";
        return $this->conn->statement($sql);
    }
    
    public function deleteCategory($categoryID)
    {
        $sql = "DELETE FROM Category WHERE categoryID = $categoryID; DELETE FROM Gallery WHERE categoryID = $categoryID;";
        return $this->conn->statement($sql);
    }
    
    public function updateCategory(Category_model $category)
    {
        $sql = "UPDATE Category SET isRoot = '$category->isRoot', categoryName = '$category->categoryName', hasGallery = '$category->hasGallery', image = '$category->image', superCategory = '$category->superCategory' WHERE categoryID = $category->categoryID;";
        return $this->conn->statement($sql);
    }
    
}


?>