<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of DBConnection
 *
 * @author Christian
 */
class DBConnection {
    
    
    
            function __construct() {
               
}
    
    
    public function query($query)
    {
        try {
             //Create connection
            $conn = new mysqli('mysql3.gigahost.dk', 'sponz', 'feuer110986FREI', 'sponz_jeniithphotography', 3306);
            //Checking...

            if($conn->connect_error)
            {
                die("Connection failed: ".$conn->connect_errno);
            }
            return $result = $conn->query($query);
//            if($result->num_rows > 0)
//            {
//                return $result;
//            }
//            else
//            {
//                return FALSE;
//            }
        } catch (Exception $ex) {
            die("DBConnection failed: ".$ex->getMessage());
        }
         finally {
            $conn->close();
            }
       
    }
    
    public function statement($statement)
    {
        try {
             //Create connection
            $conn = new mysqli('mysql3.gigahost.dk', 'sponz', 'feuer110986FREI', 'sponz_jeniithphotography', 3306);
            //Checking...

            if($conn->connect_error)
            {
                die("Connection failed: ".$conn->connect_errno);
            }
            
            if($conn->query($statement) == TRUE)
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        } catch (Exception $ex) {
            die("DBConnection failed: ".$ex->getMessage());
        }
         finally {
            $conn->close();
            }
    }
    
    public function statementReturnID($statement)
    {
        try {
             //Create connection
            $conn = new mysqli('mysql3.gigahost.dk', 'sponz', 'feuer110986FREI', 'sponz_jeniithphotography', 3306);
            //Checking...

            if($conn->connect_error)
            {
                die("Connection failed: ".$conn->connect_errno);
            }
            
            if($conn->query($statement) == TRUE)
            {
                return $conn->insert_id;
            }
            else
            {
                return FALSE;
            }
        } catch (Exception $ex) {
            die("DBConnection failed: ".$ex->getMessage());
        }
         finally {
            $conn->close();
            }
    }
}
