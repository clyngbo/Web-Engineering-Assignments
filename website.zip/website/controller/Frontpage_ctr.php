<?php
include_once 'Control_init.php';
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Frontpage_ctr
{
    private $conn;
    public function __construct() {
        $this->conn = new DBConnection();
    }
    
    public function getReview($reviewID)
    {
        $sql = "SELECT * FROM Review WHERE reviewID = $reviewID;";
        $review = new Review_model();
        $result = $this->conn->query($sql);
        while($row = $result->fetch_assoc())
        {
            $review->image = $row['image'];
            $review->location = $row['location'];
            $review->name = $row['name'];
            $review->review = $row['review'];
            $review->reviewID = $row['reviewID'];
        }
        return $review;
    }
    
    public function getAllReviews() 
    {
        $sql = "SELECT * FROM Review;";
        $reviews = new ArrayObject();
        $result = $this->conn->query($sql);
        while($row = $result->fetch_assoc())
        {
            $id = $row['reviewID'];
            $review = $this->getReview($id);
            $reviews->append($review);
        }
        return $reviews;
    }
    
    public function createReview(Review_model $review)
    {
        $sql = "INSERT INTO Review (review, `name`, location, image) VALUES ('$review->review', '$review->name', '$review->location', '$review->image');";
        return $this->conn->statement($sql);
    }
    
    public function updateReview(Review_model $review)
    {
        $sql = "UPDATE Review SET review = '$review->review', location = '$review->location', `name` =  '$review->name', `image` = '$review->image' WHERE reviewID = $review->reviewID;";
        return $this->conn->statement($sql);
    }
    
    public function deleteReview($reviewID)
    {
        $sql = "DELETE FROM Review WHERE reviewID = $reviewID;";
        return $this->conn->statement($sql);
    }
    
    public function getFrontpageText()
    {
        $sql = "SELECT * FROM Frontpage WHERE frontpageID = (SELECT MAX(frontpageID) FROM Frontpage);";
        $result = $this->conn->query($sql);
        $frontpage = new Frontpage_model();
        while($row = $result->fetch_assoc())
        {
            $frontpage->frontpageID = $row['frontpageID'];
            $frontpage->frontpageText = $row['frontpageText'];
        }
        return $frontpage;
    }
    
    public function createFrontpageText(Frontpage_model $frontpageText)
    {
        $sql = "INSERT INTO Frontpage (FrontpageText) VALUES ('$frontpageText->frontpageText');";
        return $this->conn->statement($sql);
    }
    
    public function deleteFrontpageText()
    {
        $sql = "DELETE FROM Frontpage WHERE frontpageID >= 0;";
        return $this->conn->statement($sql);
    }

        public function getFrontpageGallery()
    {
        $sql = "SELECT * FROM FrontpageGallery;";
        $result = $this->conn->query($sql);
        $gals = new ArrayObject();
        while($row = $result->fetch_assoc())
        {
            $gal = new FrontpageGallery_model();
            $gal->frontpageGalleryID = $row['frontpageGalleryID'];
            $gal->image = $row['image'];
            $gals->append($gal);
        }
        return $gals;
    }
    
    public function createFrontpageGallery(FrontpageGallery_model $frontpageGallery)
    {
        $sql = "INSERT INTO FrontpageGallery(image) VALUES ('$frontpageGallery->image');";
        return $this->conn->statement($sql);
    }

    public function updateFrontpageGallery(FrontpageGallery_model $frontpageGallery)
    {
        $sql = "UPDATE FrontpageGallery SET `image` = '$frontpageGallery->image' WHERE frontpageGalleryID = '$frontpageGallery->frontpageGalleryID';";
        return $this->conn->statement($sql);
    }
    
    public function deleteFrontpageGallery($frontpageGallerID)
    {
        $sql = "DELETE FROM FrontpageGallery WHERE frontpageGallery = $frontpageGallerID;";
        return $this->conn->statement($sql);
    }
}