<?php
include_once 'Control_init.php';
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class User_ctr
{
    function __construct() {
        $this->conn = new DBConnection();
    }
    
    private $conn;
    
    public function getUser($name)
    {
        $sql = "SELECT * FROM User WHERE `name` = $name;";
        $result = $this->conn->query($sql);
        $user = new User_model();
        while ($row = $result->fetch_assoc())
        {
            $user->name = $row['name'];
            $user->password = $row['password'];
            $user->userID = $row['userID'];
        }
        return $user;
    }
    
    public function createUser(User_model $user)
    {
        $sql = "INSERT INTO User(`name`, `password`) VALUES ('$user->name', '$user->password');";
        return $this->conn->statement($sql);
    }
    
    public function updatePassword(User_model $user)
    {
        $sql = "UPDATE User SET password = '$user->password' WHERE userID = $user->userID;";
        return $this->conn->statement($sql);
    }
    
    public function deleteUser($userID)
    {
        $sql = "DELETE FROM User WHERE userID = $userID;";
        return $this->conn->statement($sql);
    }
}




?>