<?php
include_once 'Control_init.php';
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Price_ctr
{
    private $conn;
    public function __construct() {
        $this->conn = new DBConnection();
    }
    
    public function getPrice() 
    {
        $sql = "SELECT * FROM Price WHERE priceID = (SELECT MAX(priceID) FROM Price);";
        $result = $this->conn->query($sql);
        $price = new Price_model();
        while($row = $result->fetch_assoc())
        {
            $price->priceID = $row['priceID'];
            $price->priceText = $row['priceText'];
        }
        return $price;
    }
    
    public function updatePrice(Price_model $price)
    {
        $sql = "UPDATE Price SET priceText = '$price->priceText' WHERE priceID = $price->priceID;";
        return $this->conn->statement($sql);
    }
    
    public function createPrice(Price_model $price)
    {
        $sql = "INSERT INTO Price(priceText) VALUES (priceText = '$price->priceText')";
        return $this->conn->statement($sql);
    }
    public function deletePrice($priceID)
    {
        return $this->conn->statement("DELETE FROM Price WHERE priceID = $priceID;");
    }
}

?>