<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function getMenu()
{
    ?>
<div id="logo">
    <a href="index.php"><img src="images/logo.png" alt="logo" id="logo-img"></a>
</div>
        <div class="sidenav" id="mySidenav">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav();">&times;</a>
            <a href="galleri.php">Galleri</a>
            <a href="priser.php">Priser</a>
            <a href="kontakt.php">Kontakt</a>
        </div>
<span class="menuButton" onclick="openNav()">&#9776;</span>
    <?php
}

?>